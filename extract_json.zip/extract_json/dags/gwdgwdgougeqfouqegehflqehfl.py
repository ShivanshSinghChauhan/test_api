from airflow.models.dag import DAG
from airflow.models.baseoperator import BaseOperator
from airflow.models.baseoperator import BaseOperator


gwdgwdgougeqfouqegehflqehfl = DAG(**{"dag_id": "gwdgwdgougeqfouqegehflqehfl"})


thywtersh = BaseOperator(
    **{"task_id": "thywtersh"}, dag=gwdgwdgougeqfouqegehflqehfl
)
rtwhsrtjhtwr = BaseOperator(
    **{"task_id": "rtwhsrtjhtwr"}, dag=gwdgwdgougeqfouqegehflqehfl
)


thywtersh >> rtwhsrtjhtwr
