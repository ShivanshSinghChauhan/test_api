class ShareDataWorkflow():

    def __int__(self, WorkflowID, WorkflowName, WorkflowVersion, WorkflowDescription, WorkflowDefination):

        self.WorkflowID = WorkflowID
        self.WorkflowName = WorkflowName
        self.WorkflowVersion = WorkflowVersion
        self.WorkflowDescription= WorkflowDescription
        self.WorkflowDefination= WorkflowDefination

        {"WorkflowID":"",
         "WorkflowName": "", 
         "WorkflowVersion": 1.0, 
         "WorkflowDescription": "", 
         "WorkflowDefination": ""}
