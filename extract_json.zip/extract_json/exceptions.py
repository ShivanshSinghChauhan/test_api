class OperatorMarshallError(Exception):
    ...


class DocstringParseError(Exception):
    ...


class InitError(Exception):
    ...


class DagHandlerValidationError(Exception):
    ...