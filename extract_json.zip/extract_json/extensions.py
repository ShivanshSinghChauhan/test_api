from neo4j_db import Neo4j

neo4j = Neo4j()